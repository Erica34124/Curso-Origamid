import React from 'react';

const ProdutoAvaliacao = () => {
  return (
    <div>
      <h2>Produto Avaliação</h2>
    </div>
  );
};

export default ProdutoAvaliacao;
